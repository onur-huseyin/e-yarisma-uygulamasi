import"./BFXPdK3x.js";const r=""+new URL("asil-logo.B1lSZz8y.png",import.meta.url).href;export{r as _};
